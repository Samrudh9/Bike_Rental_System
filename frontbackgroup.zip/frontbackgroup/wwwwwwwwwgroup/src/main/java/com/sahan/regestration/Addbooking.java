package com.sahan.regestration;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;


public class Addbooking extends HttpServlet {
    private static final long serialVersionUID = 1L;

    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html");
        PrintWriter out = response.getWriter();

    	String id = request.getParameter("id");
		String model = request.getParameter("model");
		String pickupDateTime = request.getParameter("pickupDateTime");
		String dropoffDateTime = request.getParameter("dropoffDateTime");
		String totalPrice = request.getParameter("totalPrice");
		String status = request.getParameter("status");
        Connection conn = null;
        PreparedStatement pstmt = null;

        try {
			String jdbcUrl = "jdbc:mysql://localhost:3306/bookingdata1";
			String dbUser = "root";
			String dbPassword = "sahan";

            Class.forName("com.mysql.cj.jdbc.Driver");

            conn = DriverManager.getConnection(jdbcUrl, dbUser, dbPassword);

            String sql = "INSERT INTO bookinginfo (id, model,pickupDateTime , dropoffDateTime, totalPrice,status) VALUES (?,?, ?, ?, ?,?)";
            pstmt = conn.prepareStatement(sql);
    		pstmt.setString(1, id);
			pstmt.setString(2, model);
			pstmt.setString(3, pickupDateTime );
			pstmt.setString(4,dropoffDateTime);
			pstmt.setString(5, totalPrice);
			pstmt.setString(6, status );
            int rowsAffected = pstmt.executeUpdate();
            if (rowsAffected > 0) {
                response.sendRedirect("bookbike.jsp");
            } else {
                out.println("<h2>Failed to add Bikes</h2>");
            }
        } catch (Exception e) {
            out.println("<h2>Error: " + e.getMessage() + "</h2>");
            e.printStackTrace();
        } finally {
            try {
                if (pstmt != null) {
                    pstmt.close();
                }
                if (conn != null) {
                    conn.close();
                }
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
    }
}
