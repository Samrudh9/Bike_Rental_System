package sahan.upload;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;

@WebServlet("/AddbikeServlet")
public class AddBikeServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;

    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html");
        PrintWriter out = response.getWriter();

        String model = request.getParameter("model");
        String city = request.getParameter("city");
        String location = request.getParameter("location");
        String price = request.getParameter("price");
        String image = request.getParameter("image");

        Connection conn = null;
        PreparedStatement pstmt = null;

        try {
            String jdbcUrl = "jdbc:mysql://localhost:3306/bikedata1";
            String dbUser = "root";
            String dbPassword = "sahan";

            Class.forName("com.mysql.cj.jdbc.Driver");

            conn = DriverManager.getConnection(jdbcUrl, dbUser, dbPassword);

            String sql = "INSERT INTO bikes (model, city, location, price, image) VALUES (?, ?, ?, ?, ?)";
            pstmt = conn.prepareStatement(sql);
            pstmt.setString(1, model);
            pstmt.setString(2, city);
            pstmt.setString(3, location);
            pstmt.setString(4, price);
            pstmt.setString(5, image);
       

            int rowsAffected = pstmt.executeUpdate();
            if (rowsAffected > 0) {
                response.sendRedirect("Upload.jsp");
            } else {
                out.println("<h2>Failed to add Bikes</h2>");
            }
        } catch (Exception e) {
            out.println("<h2>Error: " + e.getMessage() + "</h2>");
            e.printStackTrace();
        } finally {
            try {
                if (pstmt != null) {
                    pstmt.close();
                }
                if (conn != null) {
                    conn.close();
                }
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
    }
}
